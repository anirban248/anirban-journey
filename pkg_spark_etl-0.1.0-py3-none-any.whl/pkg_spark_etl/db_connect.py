import spark_session as ss

def connect_postgres(appName: str, in_table: str):
    sp = ss.get_spark_session(appName)

    properties = {'user':'postgres',
              'password':'postgres',
              'driver':'org.postgresql.Driver'}

    url = 'jdbc:postgresql://localhost:5432/lego'

    df = sp.read.jdbc(url=url,properties=properties, table=in_table)

    return df
