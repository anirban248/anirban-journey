import spark_session as ss
import db_connect
import flat_file

#extract section
table_list = ['lego_sets','lego_themes','lego_inventory_sets']
app = 'lego_themes_per_year'
df_tables = {}
for i in table_list:
    df_tables.update({'df_'+i: db_connect.connect_postgres(app, i)})


#transform section

df1 = (df_tables['df_lego_sets'].filter(df_tables['df_lego_sets'].year > 2000)
       .join(df_tables['df_lego_themes'],df_tables['df_lego_sets'].theme_id == df_tables['df_lego_themes'].id,how = 'inner')
       .join(df_tables['df_lego_inventory_sets'],df_tables['df_lego_sets'].set_num == df_tables['df_lego_inventory_sets'].set_num,how = 'inner')
       .groupby(['year']).agg(ss.sf.count('theme_id').alias('theme_count'),ss.sf.sum('quantity').alias('quantity_in_stock'))
       )

#load to csv
df1.write.option('header','true').mode('overwrite').csv(flat_file.target_csv())



