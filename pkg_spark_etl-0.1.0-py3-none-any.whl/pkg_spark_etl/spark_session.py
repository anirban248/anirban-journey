from pyspark.sql import SparkSession
import  pyspark.sql.functions as sf

def get_spark_session(appName:str) -> SparkSession:
 sp = SparkSession.builder.config('spark.jars','postgresql-42.7.7.jar').appName(appName).getOrCreate()
 return sp

def get_spark_functions():
    return sf