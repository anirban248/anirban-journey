def target_csv() -> str:
    path = 'D:\Study\code\\anir248_learn\Python_programs\data_libraries\pyspark\exercises\spark-warehouse\\'
    filename = 'lego_stock_themes_per_year.csv'
    target = path + filename
    return target